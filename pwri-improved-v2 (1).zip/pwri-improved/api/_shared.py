"""
Shared helpers for Vercel serverless Python functions.

Usage:
    from _shared import cors_headers, json_response, error_response, get_mongo_db, get_supabase
"""
from __future__ import annotations

import json
import os
import logging
from typing import Any

log = logging.getLogger(__name__)

CORS = {
    "Access-Control-Allow-Origin": os.environ.get("CORS_ORIGIN", "*"),
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": (
        "Content-Type, Authorization, x-user-id, x-cron-secret, x-plant-id"
    ),
}


def cors_headers(handler_instance, status: int = 204):
    """Write CORS pre-flight headers and status."""
    handler_instance.send_response(status)
    for k, v in CORS.items():
        handler_instance.send_header(k, v)
    handler_instance.end_headers()


def _write_json(handler_instance, status: int, payload: Any):
    body = json.dumps(payload, default=str).encode()
    handler_instance.send_response(status)
    handler_instance.send_header("Content-Type", "application/json")
    handler_instance.send_header("Content-Length", str(len(body)))
    for k, v in CORS.items():
        handler_instance.send_header(k, v)
    handler_instance.end_headers()
    handler_instance.wfile.write(body)


def json_response(handler_instance, payload: Any, status: int = 200):
    _write_json(handler_instance, status, payload)


def error_response(handler_instance, message: str, status: int = 400):
    _write_json(handler_instance, status, {"error": message})


def read_body(handler_instance) -> dict:
    length = int(handler_instance.headers.get("Content-Length", 0))
    if length == 0:
        return {}
    raw = handler_instance.rfile.read(length)
    try:
        return json.loads(raw)
    except Exception:
        return {}


def get_bearer(handler_instance) -> str | None:
    auth = handler_instance.headers.get("Authorization", "")
    if auth.lower().startswith("bearer "):
        return auth.split(" ", 1)[1].strip() or None
    return None


# ---------------------------------------------------------------------------
# MongoDB (Motor async is not available in Vercel Python runtime — use PyMongo)
# ---------------------------------------------------------------------------

_mongo_client = None
_mongo_db = None


def get_mongo_db():
    """Return a synchronous PyMongo database handle (lazy singleton)."""
    global _mongo_client, _mongo_db
    if _mongo_db is not None:
        return _mongo_db
    uri = os.environ.get("MONGODB_URI")
    if not uri:
        raise RuntimeError("MONGODB_URI is not configured.")
    from pymongo import MongoClient
    _mongo_client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    db_name = os.environ.get("MONGO_DB_NAME", "pwri")
    _mongo_db = _mongo_client[db_name]
    return _mongo_db


# ---------------------------------------------------------------------------
# Supabase
# ---------------------------------------------------------------------------

def get_supabase(access_token: str | None = None):
    """Return a Supabase client, optionally with user JWT attached."""
    from supabase import create_client
    url = os.environ.get("SUPABASE_URL")
    key = os.environ.get("SUPABASE_ANON_KEY")
    if not url or not key:
        raise RuntimeError("SUPABASE_URL / SUPABASE_ANON_KEY not configured.")
    client = create_client(url, key)
    if access_token:
        try:
            client.postgrest.auth(access_token)
        except Exception:
            pass
    return client


def get_supabase_admin():
    """Return a Supabase admin client using the service-role key."""
    from supabase import create_client
    url = os.environ.get("SUPABASE_URL")
    key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
    if not url or not key:
        raise RuntimeError("SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not configured.")
    return create_client(url, key)


# ---------------------------------------------------------------------------
# Auth / RBAC helpers
# ---------------------------------------------------------------------------

def require_admin(handler_instance) -> dict | None:
    """
    Verify the bearer JWT and confirm the user has the 'Admin' role.
    Returns the decoded JWT claims dict on success.
    Writes a 401/403 error and returns None on failure.
    """
    token = get_bearer(handler_instance)
    if not token:
        error_response(handler_instance, "Missing Authorization header.", 401)
        return None
    try:
        import jwt as pyjwt
        secret = os.environ.get("SUPABASE_JWT_SECRET", "")
        claims = pyjwt.decode(token, secret, algorithms=["HS256"],
                               options={"verify_exp": True})
        roles = claims.get("user_roles", []) or []
        if "Admin" not in roles:
            error_response(handler_instance, "Admin role required.", 403)
            return None
        return claims
    except Exception as exc:
        log.warning("JWT verification failed: %s", exc)
        error_response(handler_instance, "Invalid or expired token.", 401)
        return None


def verify_cron_secret(handler_instance) -> bool:
    """Verify the x-cron-secret header matches CRON_SECRET env var."""
    expected = os.environ.get("CRON_SECRET", "")
    provided = handler_instance.headers.get("x-cron-secret", "")
    if not expected or provided != expected:
        error_response(handler_instance, "Forbidden.", 403)
        return False
    return True
