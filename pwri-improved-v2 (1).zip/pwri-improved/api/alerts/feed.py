"""
Vercel Serverless Function: GET /api/alerts/feed
Unified alerts from downtime, blending, and compliance snapshots.
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler
from typing import Any
from urllib.parse import urlparse, parse_qs

log = logging.getLogger(__name__)


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def do_GET(self):
        try:
            qs = parse_qs(urlparse(self.path).query)
            plant_id = (qs.get("plant_id") or [None])[0]
            days = int((qs.get("days") or ["7"])[0])
            days = max(1, min(days, 90))

            since = (datetime.utcnow() - timedelta(days=days)).date().isoformat()
            today = datetime.utcnow().date().isoformat()

            from api._shared import get_mongo_db
            db = get_mongo_db()

            alerts: list[dict[str, Any]] = []
            q_plant: dict[str, Any] = {}
            if plant_id:
                q_plant["plant_id"] = plant_id

            # ---- Downtime alerts ----------------------------------------
            dt_q = {**q_plant, "event_date": {"$gte": since, "$lte": today}}
            events_by_day: dict[str, list[dict]] = {}
            for d in db.downtime_events.find(dt_q, {"_id": 0}):
                key = str(d.get("event_date", ""))[:10]
                events_by_day.setdefault(key, []).append(d)

            for day, evs in events_by_day.items():
                total = sum(float(e.get("duration_hrs") or 0) for e in evs)
                long_ones = [e for e in evs if float(e.get("duration_hrs") or 0) >= 12]
                if long_ones:
                    alerts.append({
                        "kind": "downtime", "severity": "high", "date": day,
                        "plant_id": long_ones[0].get("plant_id"),
                        "plant_name": long_ones[0].get("plant_name"),
                        "title": f"Prolonged shutdown · {long_ones[0].get('subsystem')}",
                        "detail": f"{long_ones[0].get('duration_hrs')}h — {(long_ones[0].get('cause') or long_ones[0].get('raw_text', ''))[:80]}",
                        "count": len(long_ones),
                    })
                elif len(evs) >= 3 and total >= 6:
                    alerts.append({
                        "kind": "downtime", "severity": "medium", "date": day,
                        "plant_id": evs[0].get("plant_id"),
                        "plant_name": evs[0].get("plant_name"),
                        "title": f"Abnormal downtime · {len(evs)} events / {total:.1f}h",
                        "detail": "Multiple short shutdowns in one day.",
                        "count": len(evs),
                    })

            # ---- Blending alerts ----------------------------------------
            be_q = {**q_plant, "event_date": {"$gte": since}}
            for d in list(db.blending_events.find(be_q, {"_id": 0}).sort("event_date", -1).limit(30)):
                alerts.append({
                    "kind": "blending", "severity": "info",
                    "date": str(d.get("event_date", ""))[:10],
                    "plant_id": d.get("plant_id"),
                    "plant_name": d.get("plant_name"),
                    "title": f"Bypass · {d.get('well_name')}",
                    "detail": f"Injected {d.get('volume_m3')} m³ into product water.",
                })

            # ---- Compliance snapshot alerts --------------------------------
            snap_q = {**q_plant}
            seen_plants: set[str] = set()
            for s in list(db.compliance_snapshots.find(snap_q, {"_id": 0}).sort("evaluated_at", -1).limit(20)):
                pid = s.get("plant_id")
                if pid in seen_plants:
                    continue
                seen_plants.add(pid)
                for v in s.get("violations", []):
                    severity = v.get("severity", "medium")
                    if severity not in ("high", "medium"):
                        continue  # only surface significant violations in feed
                    alerts.append({
                        "kind": "compliance",
                        "severity": severity,
                        "date": str(s.get("summary_date", ""))[:10],
                        "plant_id": pid,
                        "plant_name": s.get("plant_name"),
                        "title": v.get("message", "Compliance violation"),
                        "detail": f"Metric: {v.get('metric')} = {v.get('value')} (limit {v.get('threshold')})",
                        "code": v.get("code"),
                    })

            # Sort: high > medium > low/info, then recent-first
            sev_rank = {"high": 0, "medium": 1, "low": 2, "info": 3}
            alerts.sort(key=lambda a: (
                sev_rank.get(a.get("severity", "info"), 9),
                -(int(str(a.get("date", "")).replace("-", "") or 0))
            ))
            capped = alerts[:100]

            self._json(200, {"count": len(capped), "alerts": capped, "days": days})

        except Exception as e:
            log.exception("alerts/feed failed")
            self._error(500, str(e))

    def _json(self, status: int, payload: Any):
        body = json.dumps(payload, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: int, message: str):
        self._json(status, {"error": message})

    def log_message(self, *args):
        pass
