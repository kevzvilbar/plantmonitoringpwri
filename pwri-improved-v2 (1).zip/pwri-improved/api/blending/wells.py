"""
Vercel Serverless Function: GET|POST /api/blending/wells
Manages blending well tags (MongoDB-backed).
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from http.server import BaseHTTPRequestHandler
from typing import Any
from urllib.parse import urlparse, parse_qs

log = logging.getLogger(__name__)


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers",
                         "Content-Type, Authorization, x-user-id")
        self.end_headers()

    def do_GET(self):
        try:
            qs = parse_qs(urlparse(self.path).query)
            plant_id = (qs.get("plant_id") or [None])[0]

            from api._shared import get_mongo_db
            db = get_mongo_db()

            q: dict[str, Any] = {}
            if plant_id:
                q["plant_id"] = plant_id

            wells = list(db.blending_wells.find(q, {"_id": 0}).sort("tagged_at", -1))
            # Convert datetime objects to ISO strings
            for w in wells:
                if isinstance(w.get("tagged_at"), datetime):
                    w["tagged_at"] = w["tagged_at"].isoformat()

            self._json(200, {"wells": wells})
        except Exception as e:
            log.exception("blending/wells GET failed")
            self._error(500, str(e))

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            body: dict[str, Any] = {}
            if length:
                body = json.loads(self.rfile.read(length))

            # Route to toggle or audit based on URL path
            path = urlparse(self.path).path
            if path.endswith("/toggle"):
                self._toggle(body)
            elif path.endswith("/audit"):
                self._audit(body)
            else:
                self._error(404, "Endpoint not found")
        except Exception as e:
            log.exception("blending/wells POST failed")
            self._error(500, str(e))

    def _toggle(self, body: dict):
        well_id = body.get("well_id")
        plant_id = body.get("plant_id")
        is_blending = body.get("is_blending", False)
        user_id = self.headers.get("x-user-id")

        if not well_id or not plant_id:
            self._error(400, "well_id and plant_id are required")
            return

        from api._shared import get_mongo_db
        db = get_mongo_db()

        if is_blending:
            doc = {
                "well_id": well_id,
                "plant_id": plant_id,
                "well_name": body.get("well_name", ""),
                "plant_name": body.get("plant_name", ""),
                "tagged_by": user_id,
                "tagged_at": datetime.utcnow(),
                "note": body.get("note", ""),
            }
            db.blending_wells.update_one(
                {"well_id": well_id}, {"$set": doc}, upsert=True
            )
            self._json(200, {"ok": True, "is_blending": True, "well_id": well_id})
        else:
            db.blending_wells.delete_one({"well_id": well_id})
            self._json(200, {"ok": True, "is_blending": False, "well_id": well_id})

    def _audit(self, body: dict):
        required = ["plant_id", "well_id", "event_date", "volume_m3"]
        for field in required:
            if field not in body:
                self._error(400, f"Missing required field: {field}")
                return

        from api._shared import get_mongo_db
        db = get_mongo_db()

        doc = {
            "plant_id": body["plant_id"],
            "well_id": body["well_id"],
            "well_name": body.get("well_name", ""),
            "plant_name": body.get("plant_name", ""),
            "event_date": body["event_date"],
            "volume_m3": float(body["volume_m3"]),
            "noted_at": datetime.utcnow(),
        }
        db.blending_events.insert_one(doc)
        self._json(200, {"ok": True})

    def _json(self, status: int, payload: Any):
        body = json.dumps(payload, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: int, message: str):
        self._json(status, {"error": message})

    def log_message(self, *args):
        pass
