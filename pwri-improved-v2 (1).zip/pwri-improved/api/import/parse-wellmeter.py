"""
Vercel Serverless Function: POST /api/import/parse-wellmeter
Accepts an XLSX file upload and returns a structured preview.
Does NOT persist — the frontend commits rows into Supabase.
"""
from __future__ import annotations

import io
import json
import logging
from http.server import BaseHTTPRequestHandler
from typing import Any

log = logging.getLogger(__name__)

MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MB


def _parse_multipart(body: bytes, content_type: str) -> tuple[str, bytes]:
    """Extract the first file from a multipart/form-data body."""
    # Find boundary
    boundary = None
    for part in content_type.split(";"):
        part = part.strip()
        if part.startswith("boundary="):
            boundary = part[9:].strip('"').encode()
            break
    if not boundary:
        raise ValueError("No boundary found in Content-Type")

    # Split body by boundary
    delimiter = b"--" + boundary
    parts = body.split(delimiter)

    for part in parts[1:]:
        if part == b"--\r\n" or part == b"--":
            break
        # Split headers from content
        if b"\r\n\r\n" not in part:
            continue
        headers_raw, content = part.split(b"\r\n\r\n", 1)
        # Remove trailing \r\n
        content = content.rstrip(b"\r\n")
        headers_text = headers_raw.decode("utf-8", errors="replace")
        # Check if this part has a filename (it's a file field)
        if 'filename="' in headers_text:
            # Extract filename
            for h in headers_text.split("\r\n"):
                if "filename=" in h:
                    fname = h.split('filename="')[1].split('"')[0]
                    return fname, content
    raise ValueError("No file part found in multipart body")


def _parse_xlsx(data: bytes) -> dict:
    """Parse XLSX data into a structured preview."""
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(data), data_only=True)
    ws = wb.active

    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return {"rows": [], "warnings": ["Empty workbook"]}

    # Try to auto-detect header row (first non-empty row)
    header_row_idx = 0
    for i, row in enumerate(rows[:10]):
        non_empty = [c for c in row if c is not None]
        if len(non_empty) >= 3:
            header_row_idx = i
            break

    headers = [str(h).strip() if h is not None else f"col_{j}"
               for j, h in enumerate(rows[header_row_idx])]

    parsed_rows = []
    warnings = []
    STATUS_KEYWORDS = {"defective", "shut-off", "shutoff", "no reading", "offline"}

    for row_idx, row in enumerate(rows[header_row_idx + 1:], start=header_row_idx + 2):
        if all(v is None for v in row):
            continue  # skip blank rows

        record: dict[str, Any] = {}
        for col_idx, (header, value) in enumerate(zip(headers, row)):
            record[header] = value

        # Detect status flags
        flags: list[str] = []
        for key, val in record.items():
            if val and isinstance(val, str):
                low = val.lower().strip()
                if any(kw in low for kw in STATUS_KEYWORDS):
                    flags.append(f"{key}={val}")

        # Detect negative/inconsistent volume
        prev = record.get("Previous Reading") or record.get("previous_reading")
        curr = record.get("Current Reading") or record.get("current_reading")
        if prev is not None and curr is not None:
            try:
                if float(curr) < float(prev):
                    flags.append("current<previous")
                    warnings.append(f"Row {row_idx}: Current reading < Previous reading")
            except (TypeError, ValueError):
                pass

        record["_row"] = row_idx
        record["_flags"] = flags
        record["_status"] = "flagged" if flags else "ok"
        parsed_rows.append(record)

    return {
        "headers": headers,
        "rows": parsed_rows[:500],  # cap preview at 500 rows
        "total_rows": len(parsed_rows),
        "flagged_count": sum(1 for r in parsed_rows if r["_status"] == "flagged"),
        "warnings": warnings[:20],
    }


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def do_POST(self):
        try:
            content_type = self.headers.get("Content-Type", "")
            length = int(self.headers.get("Content-Length", 0))

            if length > MAX_UPLOAD_BYTES:
                self._error(413, "File too large (limit 10MB)")
                return

            body = self.rfile.read(length)

            if "multipart/form-data" in content_type:
                filename, file_data = _parse_multipart(body, content_type)
            else:
                self._error(400, "Expected multipart/form-data")
                return

            fname_lower = filename.lower()
            if not (fname_lower.endswith(".xlsx") or fname_lower.endswith(".xlsm")):
                self._error(400, "Only .xlsx / .xlsm files are supported")
                return

            if not file_data:
                self._error(400, "Empty file")
                return

            result = _parse_xlsx(file_data)
            self._json(200, result)

        except ValueError as e:
            self._error(400, str(e))
        except Exception as e:
            log.exception("import/parse-wellmeter failed")
            self._error(500, f"Failed to parse: {e}")

    def _json(self, status: int, payload: Any):
        body = json.dumps(payload, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: int, message: str):
        self._json(status, {"error": message})

    def log_message(self, *args):
        pass
