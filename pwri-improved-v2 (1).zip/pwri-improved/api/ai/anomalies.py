"""
Vercel Serverless Function: POST /api/ai/anomalies
Stateless anomaly detection on meter reading arrays.
"""
from __future__ import annotations

import json
import logging
import os
from http.server import BaseHTTPRequestHandler
from typing import Any

log = logging.getLogger(__name__)

ANOMALY_SYSTEM = """You are an anomaly-detection reviewer for water-plant meter readings.

You will be given a JSON list of daily readings for one or more wells. For each clearly
abnormal point (spike, drop, frozen value, repeated 'defective meter', 'shutoff'
cluster, Final<Initial, etc.), output a single entry.

Return STRICT JSON only, matching this schema:

{
  "anomalies": [
    {
      "well": "string",
      "date": "YYYY-MM-DD",
      "type": "spike|drop|frozen|defective_cluster|downtime_cluster|inconsistent|baseline_shift|other",
      "severity": "low|medium|high",
      "value": number | null,
      "baseline": number | null,
      "message": "one-sentence human description",
      "suggested_action": "one-sentence actionable recommendation"
    }
  ],
  "summary": "one-sentence overall assessment"
}

If nothing looks anomalous, return {"anomalies": [], "summary": "No anomalies detected."}.
Do not include any prose outside the JSON.
"""


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            body: dict[str, Any] = {}
            if length:
                body = json.loads(self.rfile.read(length))

            readings = body.get("readings", [])
            if not readings:
                self._error(400, "readings array is required")
                return

            api_key = os.environ.get("OPENAI_API_KEY")
            if not api_key:
                self._error(503, "OPENAI_API_KEY not configured")
                return

            import httpx
            sample = readings[:100]  # cap to avoid token overflow
            prompt = json.dumps(sample, default=str)

            resp = httpx.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={
                    "model": os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
                    "messages": [
                        {"role": "system", "content": ANOMALY_SYSTEM},
                        {"role": "user", "content": prompt},
                    ],
                    "max_tokens": 800,
                    "temperature": 0.1,
                    "response_format": {"type": "json_object"},
                },
                timeout=30,
            )
            resp.raise_for_status()
            raw = resp.json()["choices"][0]["message"]["content"]
            result = json.loads(raw)
            self._json(200, result)

        except json.JSONDecodeError as e:
            self._error(400, f"JSON parse error: {e}")
        except Exception as e:
            log.exception("ai/anomalies failed")
            self._error(500, str(e))

    def _json(self, status: int, payload: Any):
        body = json.dumps(payload, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: int, message: str):
        self._json(status, {"error": message})

    def log_message(self, *args):
        pass
