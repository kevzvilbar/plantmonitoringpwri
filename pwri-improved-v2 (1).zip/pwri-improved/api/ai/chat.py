"""
Vercel Serverless Function: POST /api/ai/chat
Handles multi-turn AI conversation with plant data context.
Uses OpenAI directly (replaces emergentintegrations dependency).
"""
from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler
from typing import Any

log = logging.getLogger(__name__)

CHAT_SYSTEM = """You are the on-duty AI analyst for a water-treatment operations system (PWRI).

You help operators understand well/plant readings, meter statuses, NRW, downtime and
chemical consumption. You speak concisely, use plain language, and always ground answers
in the data snippets you are given.

When you receive a message that includes a JSON block prefixed with "DATA:", treat it as
ground truth for that turn and cite specific numbers. If a question cannot be answered from
the data provided, say so briefly and suggest what data would be needed.

Formatting rules:
 - Keep answers under ~200 words unless explicitly asked for more.
 - Use short bullet points for multi-fact answers.
 - When listing dates, always YYYY-MM-DD.
 - Never invent plant or well names that aren't in the data.
"""


def _openai_chat(messages: list[dict]) -> str:
    """Call OpenAI chat completions and return the assistant reply text."""
    import httpx
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured.")
    payload = {
        "model": os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
        "messages": messages,
        "max_tokens": 500,
        "temperature": 0.3,
    }
    resp = httpx.post(
        "https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json=payload,
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return data["choices"][0]["message"]["content"]


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers",
                         "Content-Type, Authorization, x-user-id")
        self.end_headers()

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            body: dict[str, Any] = {}
            if length:
                body = json.loads(self.rfile.read(length))

            user_id = self.headers.get("x-user-id")
            session_id = body.get("session_id") or str(uuid.uuid4())
            message = body.get("message", "").strip()
            context_data = body.get("context_data")  # optional plant data JSON

            if not message:
                self._error(400, "message is required")
                return

            # Build messages list
            messages: list[dict] = [{"role": "system", "content": CHAT_SYSTEM}]

            # Load history from MongoDB
            db = None
            history: list[dict] = []
            try:
                from api._shared import get_mongo_db
                db = get_mongo_db()
                doc = db.ai_conversations.find_one({"session_id": session_id})
                if doc:
                    history = doc.get("messages", [])[-20:]  # cap at 20 turns
            except Exception as e:
                log.warning("MongoDB unavailable for history: %s", e)

            messages.extend(history)

            # Inject context data if provided
            user_content = message
            if context_data:
                data_str = json.dumps(context_data, default=str)[:3000]
                user_content = f"DATA:\n{data_str}\n\n{message}"

            messages.append({"role": "user", "content": user_content})

            # Call OpenAI
            reply = _openai_chat(messages)

            # Persist conversation
            new_history = history + [
                {"role": "user", "content": user_content, "ts": datetime.utcnow().isoformat()},
                {"role": "assistant", "content": reply, "ts": datetime.utcnow().isoformat()},
            ]
            if db is not None:
                try:
                    db.ai_conversations.update_one(
                        {"session_id": session_id},
                        {"$set": {
                            "session_id": session_id,
                            "user_id": user_id,
                            "messages": new_history,
                            "updated_at": datetime.utcnow(),
                        }},
                        upsert=True,
                    )
                except Exception as e:
                    log.warning("Failed to persist conversation: %s", e)

            self._json(200, {
                "session_id": session_id,
                "reply": reply,
                "message_count": len(new_history),
            })
        except Exception as e:
            log.exception("ai/chat failed")
            self._error(500, str(e))

    def _json(self, status: int, payload: Any):
        body = json.dumps(payload, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: int, message: str):
        self._json(status, {"error": message})

    def log_message(self, *args):
        pass
