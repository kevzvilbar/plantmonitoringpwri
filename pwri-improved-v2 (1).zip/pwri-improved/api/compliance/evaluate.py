"""
Vercel Serverless Function: POST /api/compliance/evaluate
Evaluates plant metrics against configured thresholds and returns violations.
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from http.server import BaseHTTPRequestHandler
from typing import Any

log = logging.getLogger(__name__)

DEFAULT_THRESHOLDS = {
    "nrw_pct_max": 20.0,
    "downtime_hrs_per_day_max": 2.0,
    "permeate_tds_max": 500.0,
    "permeate_ph_min": 6.5,
    "permeate_ph_max": 8.5,
    "raw_turbidity_max": 5.0,
    "dp_psi_max": 40.0,
    "recovery_pct_min": 70.0,
    "pv_ratio_max": 1.2,
    "chem_low_stock_days_min": 7.0,
}


def get_thresholds(db, scope: str) -> dict:
    """Load thresholds from MongoDB, falling back to defaults."""
    try:
        doc = db.compliance_thresholds.find_one({"scope": scope})
        if doc and "thresholds" in doc:
            return {**DEFAULT_THRESHOLDS, **doc["thresholds"]}
        if scope != "global":
            doc = db.compliance_thresholds.find_one({"scope": "global"})
            if doc and "thresholds" in doc:
                return {**DEFAULT_THRESHOLDS, **doc["thresholds"]}
    except Exception as e:
        log.warning("Failed to load thresholds from MongoDB: %s", e)
    return DEFAULT_THRESHOLDS.copy()


def evaluate_metrics(thresholds: dict, metrics: dict) -> list[dict]:
    """Evaluate metrics against thresholds and return violation list."""
    violations = []

    def check(code, metric, value, comparator, threshold, severity, message):
        if value is None:
            return
        try:
            v = float(value)
        except (TypeError, ValueError):
            return
        violated = (
            (comparator == ">" and v > threshold) or
            (comparator == "<" and v < threshold)
        )
        if violated:
            violations.append({
                "code": code,
                "severity": severity,
                "metric": metric,
                "value": round(v, 3),
                "threshold": threshold,
                "comparator": comparator,
                "message": message,
            })

    t = thresholds
    m = metrics

    check("nrw_high", "nrw_pct", m.get("nrw_pct"), ">",
          t["nrw_pct_max"], "high",
          f"NRW {m.get('nrw_pct', 'N/A')}% exceeds {t['nrw_pct_max']}% limit")

    check("downtime_high", "downtime_hrs", m.get("downtime_hrs"), ">",
          t["downtime_hrs_per_day_max"], "high",
          f"Downtime {m.get('downtime_hrs', 'N/A')}h exceeds {t['downtime_hrs_per_day_max']}h/day limit")

    check("tds_high", "permeate_tds", m.get("permeate_tds"), ">",
          t["permeate_tds_max"], "high",
          f"Permeate TDS {m.get('permeate_tds', 'N/A')} ppm exceeds {t['permeate_tds_max']} ppm limit")

    check("ph_low", "permeate_ph", m.get("permeate_ph"), "<",
          t["permeate_ph_min"], "medium",
          f"Permeate pH {m.get('permeate_ph', 'N/A')} below minimum {t['permeate_ph_min']}")

    check("ph_high", "permeate_ph", m.get("permeate_ph"), ">",
          t["permeate_ph_max"], "medium",
          f"Permeate pH {m.get('permeate_ph', 'N/A')} above maximum {t['permeate_ph_max']}")

    check("turbidity_high", "raw_turbidity", m.get("raw_turbidity"), ">",
          t["raw_turbidity_max"], "medium",
          f"Raw turbidity {m.get('raw_turbidity', 'N/A')} NTU exceeds {t['raw_turbidity_max']} NTU limit")

    check("dp_high", "dp_psi", m.get("dp_psi"), ">",
          t["dp_psi_max"], "medium",
          f"Differential pressure {m.get('dp_psi', 'N/A')} PSI exceeds {t['dp_psi_max']} PSI limit")

    check("recovery_pct_under", "recovery_pct", m.get("recovery_pct"), "<",
          t["recovery_pct_min"], "high",
          f"Recovery {m.get('recovery_pct', 'N/A')}% below minimum {t['recovery_pct_min']}%")

    check("pv_ratio_high", "pv_ratio", m.get("pv_ratio"), ">",
          t["pv_ratio_max"], "low",
          f"Power-volume ratio {m.get('pv_ratio', 'N/A')} kWh/m³ exceeds {t['pv_ratio_max']} limit")

    return violations


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            body: dict[str, Any] = {}
            if length:
                body = json.loads(self.rfile.read(length))

            plant_id = body.get("plant_id")
            metrics = body.get("metrics", {})
            scope_label = body.get("scope_label", plant_id or "global")
            scope = plant_id or "global"

            db = None
            thresholds = DEFAULT_THRESHOLDS.copy()
            try:
                from api._shared import get_mongo_db
                db = get_mongo_db()
                thresholds = get_thresholds(db, scope)
            except Exception as e:
                log.warning("MongoDB unavailable, using defaults: %s", e)

            violations = evaluate_metrics(thresholds, metrics)

            # Persist snapshot to MongoDB for alert feed
            if db is not None:
                try:
                    db.compliance_snapshots.update_one(
                        {"plant_id": scope},
                        {"$set": {
                            "plant_id": scope,
                            "plant_name": scope_label,
                            "violations": violations,
                            "metrics": metrics,
                            "thresholds": thresholds,
                            "evaluated_at": datetime.utcnow(),
                            "summary_date": datetime.utcnow().date().isoformat(),
                        }},
                        upsert=True,
                    )
                except Exception as e:
                    log.warning("Failed to persist compliance snapshot: %s", e)

            self._json(200, {
                "scope": scope,
                "scope_label": scope_label,
                "evaluated_at": datetime.utcnow().isoformat(),
                "violations": violations,
                "thresholds": thresholds,
                "violation_count": len(violations),
                "has_critical": any(v["severity"] == "high" for v in violations),
            })

        except Exception as e:
            log.exception("compliance/evaluate failed")
            self._error(500, str(e))

    def _json(self, status: int, payload: Any):
        body = json.dumps(payload, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: int, message: str):
        self._json(status, {"error": message})

    def log_message(self, *args):
        pass
