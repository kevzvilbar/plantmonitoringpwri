/**
 * useAlerts — React Query hook for the unified alerts feed.
 *
 * Improvements:
 * - Uses typed api.alerts.feed() client (no raw fetch)
 * - Auto-refetches every 60 s to surface new issues
 * - Exposes unread count for TopBar badge
 * - Provides `markRead()` to clear the badge without a reload
 */
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useRef } from "react";
import { api, type Alert, type AlertsFeedResponse } from "@/lib/api";
import { useAppStore } from "@/store/appStore";

export function useAlerts(days = 7) {
  const { selectedPlantId, setUnreadCount } = useAppStore();
  const qc = useQueryClient();
  const prevCountRef = useRef(0);

  const query = useQuery<AlertsFeedResponse>({
    queryKey: ["alerts-feed", selectedPlantId, days],
    queryFn: () => api.alerts.feed(selectedPlantId, days),
    refetchInterval: 60_000, // auto-refresh every minute
    staleTime: 30_000,
  });

  // Bump the unread count when the count increases
  useEffect(() => {
    const count = query.data?.count ?? 0;
    if (count > prevCountRef.current) {
      setUnreadCount(count - prevCountRef.current);
    }
    prevCountRef.current = count;
  }, [query.data?.count, setUnreadCount]);

  const markRead = useCallback(() => {
    setUnreadCount(0);
  }, [setUnreadCount]);

  const highSeverity = query.data?.alerts.filter((a) => a.severity === "high") ?? [];
  const mediumSeverity = query.data?.alerts.filter((a) => a.severity === "medium") ?? [];

  return {
    ...query,
    alerts: query.data?.alerts ?? [],
    highSeverity,
    mediumSeverity,
    markRead,
  };
}

export type { Alert };
