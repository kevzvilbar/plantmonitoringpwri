/**
 * AlertsFeed — Live alerts panel for the Dashboard.
 *
 * Shows high-severity issues first, with badge counts.
 * Clicking an alert navigates to the relevant section.
 */
import { useAlerts, type Alert } from "@/hooks/useAlerts";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "react-router-dom";
import { AlertTriangle, Info, Bell, CheckCircle2, ShieldAlert } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const SEV_CONFIG = {
  high: {
    Icon: ShieldAlert,
    badge: "destructive" as const,
    dot: "bg-rose-500",
    label: "Critical",
  },
  medium: {
    Icon: AlertTriangle,
    badge: "secondary" as const,
    dot: "bg-amber-500",
    label: "Warning",
  },
  low: {
    Icon: Info,
    badge: "outline" as const,
    dot: "bg-sky-400",
    label: "Low",
  },
  info: {
    Icon: Info,
    badge: "outline" as const,
    dot: "bg-muted-foreground/40",
    label: "Info",
  },
} as const;

const KIND_NAV: Record<Alert["kind"], string> = {
  downtime: "/operations?tab=downtime",
  blending: "/operations?tab=bypass",
  compliance: "/compliance",
  recovery: "/compliance",
};

function AlertRow({ alert }: { alert: Alert }) {
  const navigate = useNavigate();
  const cfg = SEV_CONFIG[alert.severity] ?? SEV_CONFIG.info;
  const { Icon, badge, dot } = cfg;

  const relative = (() => {
    try {
      return formatDistanceToNow(new Date(alert.date), { addSuffix: true });
    } catch {
      return alert.date;
    }
  })();

  return (
    <button
      onClick={() => navigate(KIND_NAV[alert.kind] ?? "/")}
      className="flex w-full items-start gap-3 rounded-md p-2 text-left transition-colors hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-muted">
        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold leading-none text-foreground truncate">
            {alert.title}
          </span>
          <span className={`inline-block h-1.5 w-1.5 shrink-0 rounded-full ${dot}`} />
        </div>
        {alert.plant_name && (
          <span className="text-[10px] text-muted-foreground">{alert.plant_name}</span>
        )}
        <p className="mt-0.5 text-[10px] text-muted-foreground/80 line-clamp-2">
          {alert.detail}
        </p>
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1">
        <Badge variant={badge} className="text-[9px] px-1 py-0">
          {cfg.label}
        </Badge>
        <span className="text-[9px] text-muted-foreground/60 whitespace-nowrap">{relative}</span>
      </div>
    </button>
  );
}

interface AlertsFeedProps {
  days?: number;
  maxItems?: number;
  className?: string;
}

export function AlertsFeed({ days = 7, maxItems = 15, className = "" }: AlertsFeedProps) {
  const { alerts, isLoading, highSeverity, mediumSeverity, markRead } = useAlerts(days);

  const shown = alerts.slice(0, maxItems);

  return (
    <Card className={`flex flex-col p-3 ${className}`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <Bell className="h-3.5 w-3.5 text-muted-foreground" />
          <h3 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            Alerts ({days}d)
          </h3>
        </div>
        <div className="flex gap-1">
          {highSeverity.length > 0 && (
            <Badge variant="destructive" className="text-[9px] px-1.5 py-0">
              {highSeverity.length} critical
            </Badge>
          )}
          {mediumSeverity.length > 0 && (
            <Badge variant="secondary" className="text-[9px] px-1.5 py-0">
              {mediumSeverity.length} warn
            </Badge>
          )}
        </div>
      </div>

      <ScrollArea className="flex-1 max-h-72">
        {isLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-3 p-2">
                <Skeleton className="h-6 w-6 rounded-full" />
                <div className="flex-1 space-y-1">
                  <Skeleton className="h-3 w-3/4" />
                  <Skeleton className="h-2.5 w-full" />
                </div>
              </div>
            ))}
          </div>
        ) : shown.length === 0 ? (
          <div className="flex flex-col items-center gap-1.5 py-6 text-center">
            <CheckCircle2 className="h-8 w-8 text-emerald-500/60" />
            <p className="text-xs text-muted-foreground">No alerts in the last {days} days</p>
          </div>
        ) : (
          <div className="space-y-0.5">
            {shown.map((alert, i) => (
              <AlertRow key={`${alert.kind}-${alert.date}-${i}`} alert={alert} />
            ))}
            {alerts.length > maxItems && (
              <p className="text-center text-[10px] text-muted-foreground py-1">
                +{alerts.length - maxItems} more alerts
              </p>
            )}
          </div>
        )}
      </ScrollArea>
    </Card>
  );
}
